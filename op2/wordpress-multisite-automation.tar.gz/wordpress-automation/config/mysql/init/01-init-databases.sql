-- ============================================================================
-- Script de Inicialización de Bases de Datos
-- WordPress Multi-Sitio - 10 Sitios
-- ============================================================================

-- Crear bases de datos con configuración optimizada
CREATE DATABASE IF NOT EXISTS wp_sitio1 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS wp_sitio2 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS wp_sitio3 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS wp_sitio4 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS wp_sitio5 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS wp_sitio6 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS wp_sitio7 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS wp_sitio8 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS wp_sitio9 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS wp_sitio10 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

-- Otorgar privilegios al usuario wpuser
GRANT ALL PRIVILEGES ON wp_sitio1.* TO 'wpuser'@'%';
GRANT ALL PRIVILEGES ON wp_sitio2.* TO 'wpuser'@'%';
GRANT ALL PRIVILEGES ON wp_sitio3.* TO 'wpuser'@'%';
GRANT ALL PRIVILEGES ON wp_sitio4.* TO 'wpuser'@'%';
GRANT ALL PRIVILEGES ON wp_sitio5.* TO 'wpuser'@'%';
GRANT ALL PRIVILEGES ON wp_sitio6.* TO 'wpuser'@'%';
GRANT ALL PRIVILEGES ON wp_sitio7.* TO 'wpuser'@'%';
GRANT ALL PRIVILEGES ON wp_sitio8.* TO 'wpuser'@'%';
GRANT ALL PRIVILEGES ON wp_sitio9.* TO 'wpuser'@'%';
GRANT ALL PRIVILEGES ON wp_sitio10.* TO 'wpuser'@'%';

-- Aplicar privilegios
FLUSH PRIVILEGES;

-- Crear usuario de backup (solo lectura)
CREATE USER IF NOT EXISTS 'backup_user'@'%' 
    IDENTIFIED BY 'BackupUser2024!Secure';

GRANT SELECT, LOCK TABLES, SHOW VIEW, EVENT, TRIGGER 
    ON *.* TO 'backup_user'@'%';

FLUSH PRIVILEGES;

-- ============================================================================
-- Optimizaciones iniciales de tablas
-- ============================================================================

-- Nota: Estas optimizaciones se aplicarán cuando WordPress cree las tablas
-- Se incluyen aquí como referencia para optimizaciones futuras

-- Las siguientes optimizaciones se pueden aplicar después de la instalación:
-- ALTER TABLE wp_options ENGINE=InnoDB ROW_FORMAT=COMPRESSED;
-- ALTER TABLE wp_postmeta ENGINE=InnoDB ROW_FORMAT=COMPRESSED;
-- ALTER TABLE wp_usermeta ENGINE=InnoDB ROW_FORMAT=COMPRESSED;
