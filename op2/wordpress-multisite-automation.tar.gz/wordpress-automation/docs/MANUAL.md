# Manual de Usuario - WordPress Multi-Sitio Automatizado

## 📋 Índice Rápido

1. [Instalación](#instalación)
2. [Configuración](#configuración)
3. [Uso Diario](#uso-diario)
4. [Mantenimiento](#mantenimiento)
5. [Solución de Problemas](#solución-de-problemas)

---

## 🚀 Instalación

### Requisitos
- Ubuntu 24.04 LTS
- 8GB RAM
- 50GB disco
- Acceso root

### Instalación en 1 Comando

```bash
cd /tmp
# Descargar proyecto
git clone [tu-repo] wordpress-automation
cd wordpress-automation
# Instalar TODO automáticamente
sudo bash scripts/install.sh
```

**Tiempo**: 5-10 minutos

### Siguiente Paso: Configurar Dominios

```bash
cd /opt/wordpress-multisite
sudo nano .env
```

Editar:
```env
DOMAIN_1=tudominio1.com
DOMAIN_2=tudominio2.com
# ... etc
```

### Iniciar Sistema

```bash
cd /opt/wordpress-multisite
sudo bash scripts/deploy.sh           # Iniciar servicios
sudo bash scripts/setup-ssl.sh        # Configurar SSL
sudo bash scripts/install-wordpress.sh  # Instalar WordPress
```

---

## ⚙️ Configuración

### Completar Instalación WordPress

Accede a cada dominio: `https://tudominio1.com`

Completa asistente:
1. Idioma
2. Info del sitio
3. Usuario admin
4. ¡Listo!

### Plugins Recomendados

**Caché**:
- WP Super Cache
- W3 Total Cache

**Seguridad**:
- Wordfence Security
- iThemes Security

**Optimización**:
- Smush (imágenes)
- WP Optimize

---

## 📅 Uso Diario

### Ver Estado

```bash
sudo bash scripts/status.sh
```

Muestra:
- Estado servicios
- Uso CPU/RAM/Disco
- Estado sitios web
- Info backups

### Ver Logs

```bash
# Monitor general
tail -f /opt/wordpress-multisite/logs/monitor.log

# Alertas
tail -f /opt/wordpress-multisite/logs/alerts.log

# Nginx
tail -f /opt/wordpress-multisite/logs/nginx/sitio1_access.log
```

### Comandos Rápidos

```bash
cd /opt/wordpress-multisite

# Reiniciar todo
docker compose restart

# Reiniciar servicio específico
docker compose restart nginx

# Ver servicios corriendo
docker compose ps

# Detener todo
docker compose down

# Iniciar todo
docker compose up -d
```

---

## 🛠️ Mantenimiento

### Backups

**Automático**: Cada día a las 2 AM

**Manual**:
```bash
sudo bash scripts/backup.sh
```

**Ubicación**: `/opt/wordpress-multisite/backups/`

**Retención**: 30 días

### Actualizaciones

**Automático**: Domingos 3 AM

**Manual**:
```bash
sudo bash scripts/update.sh
```

Actualiza:
- WordPress Core
- Plugins
- Temas
- Imágenes Docker

### Optimización

**Automático**: Domingos 5 AM

**Manual**:
```bash
sudo bash scripts/optimize-db.sh
```

Realiza:
- Optimización tablas
- Limpieza spam
- Limpieza revisiones
- Reparación automática

---

## 🔧 Solución de Problemas

### Sitio No Responde

```bash
# 1. Ver estado
sudo bash scripts/status.sh

# 2. Ver logs error
tail -100 /opt/wordpress-multisite/logs/nginx/sitio1_error.log

# 3. Reiniciar servicios
docker compose restart nginx php
```

### Error Base de Datos

```bash
# Verificar MySQL
docker compose ps mysql

# Reparar BD
docker compose exec mysql mysqlcheck \
  -u wpuser -p \
  --auto-repair wp_sitio1
```

### Sistema Lento

```bash
# Ver recursos
htop
docker stats

# Optimizar
sudo bash scripts/optimize-db.sh

# Limpiar caché
docker compose exec nginx sh -c "rm -rf /var/cache/nginx/*"
docker compose restart redis nginx
```

### Disco Lleno

```bash
# Ver uso
df -h
du -sh /opt/wordpress-multisite/* | sort -h

# Limpiar backups antiguos
find /opt/wordpress-multisite/backups -mtime +30 -delete

# Limpiar logs
find /opt/wordpress-multisite/logs -name "*.log" -mtime +7 -delete

# Limpiar Docker
docker system prune -a
```

---

## 📊 Características

### Automatización
✅ Backups diarios automáticos
✅ Actualizaciones semanales
✅ Monitoreo cada 5 minutos
✅ Optimización semanal BD
✅ Renovación SSL automática
✅ Alertas automáticas

### Rendimiento
✅ FastCGI Cache (Nginx)
✅ Redis (objetos/sesiones)
✅ OPcache (PHP)
✅ Compresión Gzip
✅ Caché archivos estáticos

### Seguridad
✅ Firewall UFW
✅ Fail2ban
✅ Rate Limiting
✅ SSL/TLS automático
✅ Headers seguridad
✅ Contraseñas seguras

---

## 🔑 Accesos

### phpMyAdmin
```
URL: http://TU-IP:8080
Usuario: wpuser
Password: (ver .env)
```

### FTP
```
Host: TU-IP
Puerto: 21
Usuario: ftpuser
Password: (ver .env)
```

### SSH/Terminal
```
ssh root@TU-IP
cd /opt/wordpress-multisite
```

---

## 📞 Ayuda Rápida

### Archivos Importantes
- Config: `/opt/wordpress-multisite/.env`
- Logs: `/opt/wordpress-multisite/logs/`
- Backups: `/opt/wordpress-multisite/backups/`
- Sitios: `/opt/wordpress-multisite/www/`

### Comandos Esenciales
```bash
# Estado
sudo bash scripts/status.sh

# Backup
sudo bash scripts/backup.sh

# Actualizar
sudo bash scripts/update.sh

# Optimizar
sudo bash scripts/optimize-db.sh
```

### Tareas Programadas
- **2 AM**: Backups
- **3 AM** (Domingos): Actualizaciones
- **5 AM** (Domingos): Optimización BD
- **Cada 5 min**: Monitoreo

---

## 💡 Tips

1. **Revisa logs regularmente**: `tail -f logs/monitor.log`
2. **Verifica backups**: Asegúrate que se crean diariamente
3. **Actualiza plugins**: Desde WordPress admin
4. **Usa CDN**: Cloudflare (gratis) mejora rendimiento
5. **Monitorea recursos**: `htop` y `docker stats`

---

**Versión**: 2.0  
**Sistema**: Ubuntu 24.04 + Docker  
**Capacidad**: 19,000 visitas/día  
**Sitios**: 10 WordPress independientes

Para más detalles, consulta los logs y scripts en `/opt/wordpress-multisite/`
