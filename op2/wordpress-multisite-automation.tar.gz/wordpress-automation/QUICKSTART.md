# Guía de Instalación Rápida ⚡

## Pre-requisitos

- ✅ Servidor Ubuntu 24.04 LTS recién instalado
- ✅ 8GB RAM mínimo
- ✅ 50GB disco libre
- ✅ Acceso root o sudo
- ✅ 10 dominios apuntando al servidor

## Instalación en 5 Pasos

### 1️⃣ Descargar Proyecto

```bash
cd /tmp
git clone <tu-repositorio> wordpress-automation
cd wordpress-automation
```

### 2️⃣ Ejecutar Instalación Automatizada

```bash
sudo bash scripts/install.sh
```

**Duración**: 5-10 minutos

Este script instala y configura:
- Docker y Docker Compose
- Firewall (UFW)
- Fail2ban
- Estructura de directorios
- Optimizaciones del sistema
- Tareas programadas (cron)
- Servicio systemd

**⚠️ IMPORTANTE**: Al finalizar, el script mostrará las contraseñas generadas.
¡GUÁRDALAS EN UN LUGAR SEGURO!

```
MySQL Root: [password-generada]
DB User: [password-generada]
FTP: [password-generada]
```

### 3️⃣ Configurar Dominios

```bash
cd /opt/wordpress-multisite
sudo nano .env
```

Edita estas líneas con tus dominios reales:

```env
DOMAIN_1=tudominio1.com
DOMAIN_2=tudominio2.com
DOMAIN_3=tudominio3.com
DOMAIN_4=tudominio4.com
DOMAIN_5=tudominio5.com
DOMAIN_6=tudominio6.com
DOMAIN_7=tudominio7.com
DOMAIN_8=tudominio8.com
DOMAIN_9=tudominio9.com
DOMAIN_10=tudominio10.com

ADMIN_EMAIL=tu@email.com
```

Guarda con `Ctrl+X`, `Y`, `Enter`

### 4️⃣ Iniciar Servicios

```bash
cd /opt/wordpress-multisite

# Iniciar contenedores Docker
sudo bash scripts/deploy.sh

# Configurar certificados SSL (asegúrate que los dominios apunten al servidor)
sudo bash scripts/setup-ssl.sh

# Instalar WordPress en todos los sitios
sudo bash scripts/install-wordpress.sh
```

### 5️⃣ Completar Instalación WordPress

Accede a cada dominio desde tu navegador:

```
https://tudominio1.com
https://tudominio2.com
...
```

Para cada sitio:
1. Selecciona idioma
2. Ingresa información del sitio
3. Crea usuario administrador
4. ¡Listo!

---

## Verificar Instalación

```bash
cd /opt/wordpress-multisite
sudo bash scripts/status.sh
```

Deberías ver:
- ✅ Todos los servicios corriendo
- ✅ Uso de recursos normal
- ✅ Sitios respondiendo
- ✅ Certificados SSL válidos

---

## Primeros Pasos

### Ver Logs

```bash
# Monitoreo general
tail -f /opt/wordpress-multisite/logs/monitor.log

# Alertas
tail -f /opt/wordpress-multisite/logs/alerts.log
```

### Acceder a phpMyAdmin

```
URL: http://TU-IP:8080
Usuario: wpuser
Password: [la del .env]
```

### Acceder por FTP

```
Host: TU-IP
Puerto: 21
Usuario: ftpuser
Password: [la del .env]
```

---

## Comandos Esenciales

```bash
cd /opt/wordpress-multisite

# Ver estado
sudo bash scripts/status.sh

# Backup manual
sudo bash scripts/backup.sh

# Actualizar sistema
sudo bash scripts/update.sh

# Optimizar bases de datos
sudo bash scripts/optimize-db.sh

# Reiniciar servicios
docker compose restart

# Ver logs en tiempo real
docker compose logs -f nginx
```

---

## Tareas Automáticas

El sistema ejecuta automáticamente:

| Tarea | Frecuencia | Hora |
|-------|-----------|------|
| 💾 Backups | Diario | 2:00 AM |
| 🔄 Actualizaciones | Semanal | Dom 3:00 AM |
| ⚡ Optimización BD | Semanal | Dom 5:00 AM |
| 📊 Monitoreo | Continuo | Cada 5 min |
| 🔒 Renovación SSL | Continuo | Cada 12 horas |

---

## Plugins Recomendados

Instala en cada sitio WordPress:

**Caché**:
- WP Super Cache (gratis)
- W3 Total Cache (gratis)

**Seguridad**:
- Wordfence Security (gratis)
- iThemes Security (gratis)

**Optimización**:
- Smush (imágenes, gratis)
- WP Optimize (BD, gratis)
- Autoptimize (CSS/JS, gratis)

**Backups** (adicional):
- UpdraftPlus (gratis)

---

## Optimizaciones Adicionales

### Usar CDN (Recomendado)

1. Crea cuenta en [Cloudflare](https://cloudflare.com) (gratis)
2. Cambia nameservers de tus dominios
3. Activa caché y optimizaciones
4. Instala plugin Cloudflare en WordPress

### Configurar Email

Para que WordPress pueda enviar emails:

```bash
# Instalar SMTP
apt install postfix mailutils

# O usar plugin WordPress:
# WP Mail SMTP (gratis)
```

---

## Troubleshooting Rápido

### Sitio no carga

```bash
# Reiniciar servicios
cd /opt/wordpress-multisite
docker compose restart

# Ver logs
tail -50 logs/nginx/sitio1_error.log
```

### Error 500

```bash
# Ver logs PHP
tail -50 logs/php/error.log

# Verificar permisos
chown -R www-data:www-data www/sitio1/
```

### Sin espacio en disco

```bash
# Limpiar backups antiguos
find /opt/wordpress-multisite/backups -mtime +30 -delete

# Limpiar Docker
docker system prune -a
```

---

## Siguiente Nivel

1. ✅ Lee el [Manual Completo](docs/MANUAL.md)
2. ✅ Configura [Monitoreo Externo](docs/MANUAL.md#monitoreo)
3. ✅ Implementa [Backups Remotos](docs/MANUAL.md#backups-remotos)
4. ✅ Revisa [Optimizaciones](docs/MANUAL.md#optimización)

---

**¿Problemas?** Consulta [Solución de Problemas](docs/MANUAL.md#solución-de-problemas)

**¿Preguntas?** Revisa [FAQ](docs/MANUAL.md#faq)

---

**Versión**: 2.0  
**Sistema**: Ubuntu 24.04 + Docker  
**Capacidad**: 19,000 visitas/día
