# WordPress Multi-Sitio Automatizado 🚀

Sistema completamente automatizado para gestionar 10 sitios WordPress en Ubuntu 24.04 con 8GB RAM.

## ✨ Características

- ✅ **Instalación en 1 comando** - Todo automatizado
- ✅ **10 sitios WordPress** independientes
- ✅ **Backups automáticos** diarios
- ✅ **Actualizaciones automáticas** semanales
- ✅ **SSL automático** con Let's Encrypt
- ✅ **Monitoreo continuo** cada 5 minutos
- ✅ **Optimizado** para 19,000 visitas/día
- ✅ **Alta seguridad** (UFW, Fail2ban, Rate Limiting)

## 🎯 Capacidad

| Componente | Configuración |
|------------|---------------|
| **RAM** | 8GB |
| **Sitio Principal** | 10,000 visitas/día |
| **Otros Sitios** | 1,000 visitas/día c/u |
| **Total** | ~19,000 visitas/día |

## ⚡ Instalación Rápida

```bash
# 1. Descargar proyecto
git clone <tu-repo> wordpress-automation
cd wordpress-automation

# 2. Instalar TODO (5-10 minutos)
sudo bash scripts/install.sh

# 3. Configurar dominios
sudo nano /opt/wordpress-multisite/.env

# 4. Iniciar sistema
cd /opt/wordpress-multisite
sudo bash scripts/deploy.sh
sudo bash scripts/setup-ssl.sh
sudo bash scripts/install-wordpress.sh
```

## 📋 Requisitos

- Ubuntu 24.04 LTS
- 8GB RAM mínimo
- 50GB disco libre
- 10 dominios apuntando al servidor

## 🔧 Gestión

```bash
# Ver estado
sudo bash scripts/status.sh

# Backup manual
sudo bash scripts/backup.sh

# Actualizar todo
sudo bash scripts/update.sh

# Optimizar BD
sudo bash scripts/optimize-db.sh
```

## 📊 Arquitectura

```
Docker Containers:
├── Nginx (512MB) - Servidor web + cache
├── PHP-FPM (2GB) - 50 workers dinámicos
├── MySQL (3GB) - 10 bases de datos
├── Redis (512MB) - Caché objetos/sesiones
├── FTP (128MB) - Acceso archivos
└── Certbot - SSL automático
```

## 🔐 Seguridad

- Firewall UFW configurado
- Fail2ban activo
- Rate limiting (Nginx)
- SSL/TLS forzado
- Headers de seguridad
- Passwords seguras generadas

## 📅 Automatización

| Tarea | Frecuencia | Hora |
|-------|------------|------|
| Backups | Diario | 2 AM |
| Actualizaciones | Semanal | Dom 3 AM |
| Optimización BD | Semanal | Dom 5 AM |
| Monitoreo | Continuo | Cada 5 min |
| Renovación SSL | Continuo | Cada 12h |

## 📚 Documentación

- [Manual Completo](docs/MANUAL.md)
- Scripts en `/opt/wordpress-multisite/scripts/`
- Logs en `/opt/wordpress-multisite/logs/`

## 💡 Comandos Rápidos

```bash
cd /opt/wordpress-multisite

# Servicios
docker compose ps              # Ver estado
docker compose restart         # Reiniciar
docker compose logs -f nginx   # Ver logs

# Gestión
bash scripts/status.sh         # Estado completo
bash scripts/backup.sh         # Backup ahora
bash scripts/update.sh         # Actualizar todo

# Logs
tail -f logs/monitor.log       # Monitor
tail -f logs/alerts.log        # Alertas
tail -f logs/nginx/sitio1_access.log  # Nginx
```

## 🆘 Soporte

Ver [Solución de Problemas](docs/MANUAL.md#solución-de-problemas)

## 📝 Licencia

MIT License

---

**Versión**: 2.0  
**Optimizado para**: Ubuntu 24.04 + Docker
