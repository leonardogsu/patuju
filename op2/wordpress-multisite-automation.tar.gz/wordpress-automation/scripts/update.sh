#!/bin/bash

################################################################################
# Script de Actualización Automatizada
# Actualiza WordPress, plugins y temas de forma segura
################################################################################

set -e

INSTALL_DIR="/opt/wordpress-multisite"
cd "$INSTALL_DIR"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1"
}

log_success() {
    log "✓ $1"
}

log_warning() {
    log "⚠ $1"
}

# Cargar variables
source .env

log "========================================="
log "Iniciando Proceso de Actualización"
log "========================================="

################################################################################
# Crear backup antes de actualizar
################################################################################

log "Creando backup de seguridad..."
bash scripts/backup.sh > /dev/null 2>&1 || {
    log "ERROR: No se pudo crear backup. Abortando actualizaciones."
    exit 1
}
log_success "Backup creado correctamente"

################################################################################
# Actualizar imágenes Docker
################################################################################

log "Actualizando imágenes Docker..."

docker compose pull 2>/dev/null || log_warning "Error al actualizar algunas imágenes"

log_success "Imágenes Docker actualizadas"

################################################################################
# Reiniciar servicios con nuevas imágenes
################################################################################

log "Reiniciando servicios..."
docker compose up -d --force-recreate

# Esperar a que MySQL esté listo
for i in {1..30}; do
    if docker compose exec -T mysql mysqladmin ping -h localhost --silent 2>/dev/null; then
        break
    fi
    sleep 2
done

log_success "Servicios reiniciados"

################################################################################
# Instalar WP-CLI si no existe
################################################################################

if ! docker compose exec -T php wp --version 2>/dev/null; then
    log "Instalando WP-CLI..."
    docker compose exec -T php sh -c "curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar && chmod +x wp-cli.phar && mv wp-cli.phar /usr/local/bin/wp"
    log_success "WP-CLI instalado"
fi

################################################################################
# Actualizar WordPress Core en cada sitio
################################################################################

log "========================================="
log "Actualizando WordPress Core"
log "========================================="

for i in {1..10}; do
    SITE_DIR="/var/www/html/sitio${i}"
    eval DOMAIN=\$DOMAIN_${i}
    
    log "Sitio $i ($DOMAIN)..."
    
    if [ -f "www/sitio${i}/wp-config.php" ]; then
        # Verificar versión actual
        CURRENT_VERSION=$(docker compose exec -T php wp core version --path="$SITE_DIR" --allow-root 2>/dev/null || echo "N/A")
        log "  Versión actual: $CURRENT_VERSION"
        
        # Actualizar WordPress
        log "  → Actualizando WordPress..."
        docker compose exec -T php wp core update --path="$SITE_DIR" --allow-root 2>/dev/null || log_warning "  No se pudo actualizar WordPress"
        
        # Actualizar base de datos
        log "  → Actualizando base de datos..."
        docker compose exec -T php wp core update-db --path="$SITE_DIR" --allow-root 2>/dev/null || true
        
        NEW_VERSION=$(docker compose exec -T php wp core version --path="$SITE_DIR" --allow-root 2>/dev/null || echo "N/A")
        log_success "  WordPress actualizado: $NEW_VERSION"
    else
        log_warning "  WordPress no instalado, omitiendo..."
    fi
    
    echo ""
done

################################################################################
# Actualizar plugins en cada sitio
################################################################################

log "========================================="
log "Actualizando Plugins"
log "========================================="

for i in {1..10}; do
    SITE_DIR="/var/www/html/sitio${i}"
    eval DOMAIN=\$DOMAIN_${i}
    
    log "Sitio $i ($DOMAIN)..."
    
    if [ -f "www/sitio${i}/wp-config.php" ]; then
        # Listar plugins desactualizados
        UPDATES=$(docker compose exec -T php wp plugin list --path="$SITE_DIR" --update=available --format=count --allow-root 2>/dev/null || echo "0")
        
        if [ "$UPDATES" -gt 0 ]; then
            log "  → $UPDATES plugin(s) disponible(s) para actualizar"
            docker compose exec -T php wp plugin update --all --path="$SITE_DIR" --allow-root 2>/dev/null || log_warning "  Error al actualizar algunos plugins"
            log_success "  Plugins actualizados"
        else
            log "  → Todos los plugins están actualizados"
        fi
    fi
    
    echo ""
done

################################################################################
# Actualizar temas en cada sitio
################################################################################

log "========================================="
log "Actualizando Temas"
log "========================================="

for i in {1..10}; do
    SITE_DIR="/var/www/html/sitio${i}"
    eval DOMAIN=\$DOMAIN_${i}
    
    log "Sitio $i ($DOMAIN)..."
    
    if [ -f "www/sitio${i}/wp-config.php" ]; then
        # Listar temas desactualizados
        UPDATES=$(docker compose exec -T php wp theme list --path="$SITE_DIR" --update=available --format=count --allow-root 2>/dev/null || echo "0")
        
        if [ "$UPDATES" -gt 0 ]; then
            log "  → $UPDATES tema(s) disponible(s) para actualizar"
            docker compose exec -T php wp theme update --all --path="$SITE_DIR" --allow-root 2>/dev/null || log_warning "  Error al actualizar algunos temas"
            log_success "  Temas actualizados"
        else
            log "  → Todos los temas están actualizados"
        fi
    fi
    
    echo ""
done

################################################################################
# Optimizar después de actualizar
################################################################################

log "========================================="
log "Optimizando Sistema"
log "========================================="

log "Limpiando caché..."
find www/*/wp-content/cache -type f -delete 2>/dev/null || true
docker compose exec -T nginx sh -c "rm -rf /var/cache/nginx/*" 2>/dev/null || true

log "Optimizando bases de datos..."
bash scripts/optimize-db.sh > /dev/null 2>&1 || true

log_success "Sistema optimizado"

################################################################################
# Resumen
################################################################################

log "========================================="
log "Actualización Completada"
log "========================================="

echo ""
echo -e "${GREEN}✓ Actualización completada exitosamente${NC}"
echo ""
echo "Resumen:"
echo "  - Imágenes Docker actualizadas"
echo "  - WordPress Core actualizado en todos los sitios"
echo "  - Plugins actualizados"
echo "  - Temas actualizados"
echo "  - Sistema optimizado"
echo ""
echo "Backup disponible en: $INSTALL_DIR/backups"

exit 0
