#!/bin/bash

################################################################################
# Script de Despliegue Automatizado
# Inicia todos los servicios Docker y configura WordPress
################################################################################

set -e

INSTALL_DIR="/opt/wordpress-multisite"
cd "$INSTALL_DIR"

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_success() { echo -e "${GREEN}✓${NC} $1"; }
print_error() { echo -e "${RED}✗${NC} $1"; }
print_warning() { echo -e "${YELLOW}⚠${NC} $1"; }

# Verificar que existe .env
if [ ! -f .env ]; then
    print_error "Archivo .env no encontrado"
    exit 1
fi

# Cargar variables
source .env

print_header "Iniciando Despliegue"

# Detener servicios existentes si los hay
if docker compose ps | grep -q "Up"; then
    print_warning "Deteniendo servicios existentes..."
    docker compose down
fi

# Crear redes si no existen
print_success "Configurando redes Docker..."
docker network create wordpress-network 2>/dev/null || true

# Iniciar servicios
print_success "Iniciando servicios Docker..."
docker compose up -d

# Esperar a que MySQL esté listo
print_success "Esperando a que MySQL esté listo..."
for i in {1..30}; do
    if docker compose exec -T mysql mysqladmin ping -h localhost --silent; then
        break
    fi
    sleep 2
done

# Configurar permisos
print_success "Configurando permisos..."
chown -R www-data:www-data www/
chmod -R 755 www/

print_header "Despliegue Completado"

# Mostrar estado
docker compose ps

echo ""
print_success "Servicios iniciados correctamente"
echo ""
echo "URLs de acceso:"
echo "  - phpMyAdmin: http://${SERVER_IP}:8080"
echo "  - FTP: ftp://${SERVER_IP}:21"
echo ""
echo "Siguiente paso: Configurar certificados SSL"
echo "  sudo bash scripts/setup-ssl.sh"

