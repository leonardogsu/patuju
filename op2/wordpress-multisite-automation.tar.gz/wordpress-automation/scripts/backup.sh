#!/bin/bash

################################################################################
# Script de Backup Automatizado
# Realiza backups incrementales de bases de datos y archivos
################################################################################

set -e

INSTALL_DIR="/opt/wordpress-multisite"
BACKUP_DIR="$INSTALL_DIR/backups"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=${BACKUP_RETENTION_DAYS:-30}

cd "$INSTALL_DIR"

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1"
}

log_success() {
    log "✓ $1"
}

log_error() {
    log "✗ $1"
}

# Cargar variables
source .env

log "========================================="
log "Iniciando Backup - $DATE"
log "========================================="

# Crear directorios de backup
mkdir -p "$BACKUP_DIR"/{databases,files,logs}

################################################################################
# Backup de Bases de Datos
################################################################################

log "Realizando backup de bases de datos..."

for i in {1..10}; do
    DB_NAME="wp_sitio${i}"
    BACKUP_FILE="$BACKUP_DIR/databases/${DB_NAME}_${DATE}.sql.gz"
    
    log "  → Respaldando $DB_NAME..."
    
    if docker compose exec -T mysql mysqldump \
        -u wpuser \
        -p"${DB_PASSWORD}" \
        --single-transaction \
        --quick \
        --lock-tables=false \
        "$DB_NAME" | gzip > "$BACKUP_FILE"; then
        
        SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
        log_success "  $DB_NAME respaldado ($SIZE)"
    else
        log_error "  Error al respaldar $DB_NAME"
    fi
done

################################################################################
# Backup de Archivos (Incremental)
################################################################################

log "Realizando backup incremental de archivos..."

# Backup de uploads y configuraciones
for i in {1..10}; do
    SITE_DIR="www/sitio${i}"
    eval DOMAIN=\$DOMAIN_${i}
    
    if [ -d "$SITE_DIR/wp-content/uploads" ]; then
        BACKUP_FILE="$BACKUP_DIR/files/sitio${i}_uploads_${DATE}.tar.gz"
        
        log "  → Respaldando archivos de $DOMAIN..."
        
        tar -czf "$BACKUP_FILE" \
            -C "$SITE_DIR/wp-content" \
            uploads \
            2>/dev/null || true
        
        if [ -f "$BACKUP_FILE" ]; then
            SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
            log_success "  Archivos de $DOMAIN respaldados ($SIZE)"
        fi
    fi
done

# Backup de configuraciones
BACKUP_FILE="$BACKUP_DIR/files/configs_${DATE}.tar.gz"
log "  → Respaldando configuraciones..."

tar -czf "$BACKUP_FILE" \
    .env \
    docker-compose.yml \
    nginx/ \
    php/ \
    mysql/my.cnf \
    scripts/ \
    2>/dev/null || true

if [ -f "$BACKUP_FILE" ]; then
    SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
    log_success "  Configuraciones respaldadas ($SIZE)"
fi

################################################################################
# Limpieza de Backups Antiguos
################################################################################

log "Limpiando backups antiguos (>${RETENTION_DAYS} días)..."

# Eliminar backups de bases de datos antiguos
DELETED_DB=$(find "$BACKUP_DIR/databases" -name "*.sql.gz" -mtime +${RETENTION_DAYS} -delete -print | wc -l)
log_success "  Eliminados $DELETED_DB backups de bases de datos"

# Eliminar backups de archivos antiguos
DELETED_FILES=$(find "$BACKUP_DIR/files" -name "*.tar.gz" -mtime +${RETENTION_DAYS} -delete -print | wc -l)
log_success "  Eliminados $DELETED_FILES backups de archivos"

################################################################################
# Estadísticas y Resumen
################################################################################

log "========================================="
log "Resumen del Backup"
log "========================================="

# Tamaño total de backups
TOTAL_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)
log "Tamaño total de backups: $TOTAL_SIZE"

# Número de backups
DB_COUNT=$(find "$BACKUP_DIR/databases" -name "*.sql.gz" | wc -l)
FILES_COUNT=$(find "$BACKUP_DIR/files" -name "*.tar.gz" | wc -l)

log "Backups de bases de datos: $DB_COUNT"
log "Backups de archivos: $FILES_COUNT"

# Espacio en disco
DISK_USAGE=$(df -h "$BACKUP_DIR" | awk 'NR==2{print $5}')
log "Uso de disco: $DISK_USAGE"

################################################################################
# Verificación de Integridad
################################################################################

log "Verificando integridad de backups recientes..."

# Verificar últimos 3 backups de BD
RECENT_DBS=$(find "$BACKUP_DIR/databases" -name "*.sql.gz" -mtime -1 | tail -3)
VERIFIED=0
FAILED=0

for backup in $RECENT_DBS; do
    if gzip -t "$backup" 2>/dev/null; then
        ((VERIFIED++))
    else
        ((FAILED++))
        log_error "Backup corrupto: $backup"
    fi
done

log_success "Verificados: $VERIFIED | Fallidos: $FAILED"

################################################################################
# Notificación (opcional)
################################################################################

# Si está configurado el email, enviar notificación
if [ ! -z "$ADMIN_EMAIL" ] && command -v mail &> /dev/null; then
    echo "Backup completado exitosamente el $DATE" | \
        mail -s "WordPress Backup - $DATE" "$ADMIN_EMAIL"
fi

log "========================================="
log "Backup completado exitosamente"
log "========================================="

exit 0
