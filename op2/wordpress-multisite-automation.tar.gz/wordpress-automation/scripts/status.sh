#!/bin/bash

################################################################################
# Script de Estado del Sistema
# Muestra información completa del estado de todos los servicios
################################################################################

INSTALL_DIR="/opt/wordpress-multisite"
cd "$INSTALL_DIR" 2>/dev/null || cd /opt/wordpress-multisite

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_success() { echo -e "${GREEN}✓${NC} $1"; }
print_error() { echo -e "${RED}✗${NC} $1"; }
print_warning() { echo -e "${YELLOW}⚠${NC} $1"; }
print_info() { echo -e "${CYAN}ℹ${NC} $1"; }

# Cargar variables
[ -f .env ] && source .env

################################################################################
# Información del Sistema
################################################################################

print_header "Información del Sistema"

echo "Fecha: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Hostname: $(hostname)"
echo "Uptime: $(uptime -p)"
echo ""

# CPU
CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
echo -n "CPU: ${CPU_USAGE}% "
if (( $(echo "$CPU_USAGE > 80" | bc -l) )); then
    print_error "ALTO"
elif (( $(echo "$CPU_USAGE > 60" | bc -l) )); then
    print_warning "MODERADO"
else
    print_success "NORMAL"
fi

# RAM
RAM_TOTAL=$(free -h | awk 'NR==2{print $2}')
RAM_USED=$(free -h | awk 'NR==2{print $3}')
RAM_PERCENT=$(free | grep Mem | awk '{printf "%.0f", $3/$2 * 100.0}')
echo -n "RAM: ${RAM_USED}/${RAM_TOTAL} (${RAM_PERCENT}%) "
if [ "$RAM_PERCENT" -ge 85 ]; then
    print_error "ALTO"
elif [ "$RAM_PERCENT" -ge 70 ]; then
    print_warning "MODERADO"
else
    print_success "NORMAL"
fi

# Disco
DISK_USAGE=$(df -h / | awk 'NR==2{print $5}' | sed 's/%//')
DISK_AVAILABLE=$(df -h / | awk 'NR==2{print $4}')
echo -n "Disco: ${DISK_USAGE}% usado (${DISK_AVAILABLE} libre) "
if [ "$DISK_USAGE" -ge 85 ]; then
    print_error "ALTO"
elif [ "$DISK_USAGE" -ge 70 ]; then
    print_warning "MODERADO"
else
    print_success "NORMAL"
fi

# Load Average
LOAD=$(uptime | awk -F'load average:' '{print $2}' | xargs)
echo "Load Average: $LOAD"

################################################################################
# Estado de Servicios Docker
################################################################################

print_header "Servicios Docker"

if ! docker compose ps &>/dev/null; then
    print_error "No se puede conectar a Docker"
    exit 1
fi

SERVICES=("nginx-web" "php-fpm" "mysql-db" "redis-cache" "ftp-server")
SERVICE_NAMES=("Nginx" "PHP-FPM" "MySQL" "Redis" "FTP")

for i in "${!SERVICES[@]}"; do
    service="${SERVICES[$i]}"
    name="${SERVICE_NAMES[$i]}"
    
    if docker ps --format '{{.Names}}' | grep -q "^${service}$"; then
        STATUS=$(docker inspect -f '{{.State.Status}}' "$service" 2>/dev/null)
        UPTIME=$(docker inspect -f '{{.State.StartedAt}}' "$service" 2>/dev/null | xargs -I {} date -d {} +"%Y-%m-%d %H:%M:%S")
        
        if [ "$STATUS" = "running" ]; then
            print_success "$name está corriendo (desde: $UPTIME)"
        else
            print_warning "$name está $STATUS"
        fi
    else
        print_error "$name no está corriendo"
    fi
done

################################################################################
# Uso de Recursos de Contenedores
################################################################################

print_header "Uso de Recursos por Contenedor"

docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}" | grep -E "NAME|nginx|php|mysql|redis|ftp"

################################################################################
# Estado de Bases de Datos
################################################################################

print_header "Bases de Datos"

if docker ps | grep -q "mysql-db"; then
    for i in {1..10}; do
        DB_NAME="wp_sitio${i}"
        
        if docker compose exec -T mysql mysql -u wpuser -p"${DB_PASSWORD}" -e "USE ${DB_NAME};" 2>/dev/null; then
            # Obtener tamaño de BD
            SIZE=$(docker compose exec -T mysql mysql \
                -u wpuser \
                -p"${DB_PASSWORD}" \
                -e "SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) FROM information_schema.TABLES WHERE table_schema = '${DB_NAME}';" \
                --skip-column-names --silent 2>/dev/null || echo "N/A")
            
            # Obtener número de tablas
            TABLES=$(docker compose exec -T mysql mysql \
                -u wpuser \
                -p"${DB_PASSWORD}" \
                -e "SELECT COUNT(*) FROM information_schema.TABLES WHERE table_schema = '${DB_NAME}';" \
                --skip-column-names --silent 2>/dev/null || echo "N/A")
            
            print_success "${DB_NAME}: ${SIZE} MB (${TABLES} tablas)"
        else
            print_error "${DB_NAME}: No accesible"
        fi
    done
else
    print_error "MySQL no está corriendo"
fi

################################################################################
# Estado de Sitios Web
################################################################################

print_header "Estado de Sitios Web"

for i in {1..10}; do
    eval DOMAIN=\$DOMAIN_${i}
    
    if [ -z "$DOMAIN" ]; then
        continue
    fi
    
    # Verificar si WordPress está instalado
    if [ -f "www/sitio${i}/wp-config.php" ]; then
        # Verificar respuesta HTTP
        HTTP_CODE=$(curl -o /dev/null -s -w "%{http_code}" -m 5 "http://${DOMAIN}" 2>/dev/null || echo "000")
        RESPONSE_TIME=$(curl -o /dev/null -s -w "%{time_total}" -m 5 "http://${DOMAIN}" 2>/dev/null || echo "N/A")
        
        if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "301" ] || [ "$HTTP_CODE" = "302" ]; then
            print_success "$DOMAIN (${HTTP_CODE}) - ${RESPONSE_TIME}s"
        elif [ "$HTTP_CODE" = "000" ]; then
            print_error "$DOMAIN - No responde"
        else
            print_warning "$DOMAIN (${HTTP_CODE}) - ${RESPONSE_TIME}s"
        fi
        
        # Verificar SSL si existe
        if [ -f "certbot/conf/live/${DOMAIN}/cert.pem" ]; then
            EXPIRY=$(openssl x509 -enddate -noout -in "certbot/conf/live/${DOMAIN}/cert.pem" 2>/dev/null | cut -d= -f2)
            EXPIRY_EPOCH=$(date -d "$EXPIRY" +%s 2>/dev/null || echo "0")
            CURRENT_EPOCH=$(date +%s)
            DAYS_LEFT=$(( ($EXPIRY_EPOCH - $CURRENT_EPOCH) / 86400 ))
            
            if [ "$DAYS_LEFT" -lt 30 ]; then
                print_warning "  SSL expira en $DAYS_LEFT días"
            else
                print_info "  SSL válido ($DAYS_LEFT días restantes)"
            fi
        fi
    else
        print_warning "$DOMAIN - WordPress no instalado"
    fi
done

################################################################################
# Backups
################################################################################

print_header "Información de Backups"

if [ -d "backups" ]; then
    BACKUP_SIZE=$(du -sh backups 2>/dev/null | cut -f1)
    DB_BACKUPS=$(find backups/databases -name "*.sql.gz" 2>/dev/null | wc -l)
    FILE_BACKUPS=$(find backups/files -name "*.tar.gz" 2>/dev/null | wc -l)
    LAST_BACKUP=$(find backups/databases -name "*.sql.gz" -type f -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -1 | cut -d' ' -f2- | xargs -I {} basename {})
    
    echo "Tamaño total: $BACKUP_SIZE"
    echo "Backups de BD: $DB_BACKUPS"
    echo "Backups de archivos: $FILE_BACKUPS"
    echo "Último backup: $LAST_BACKUP"
    
    # Verificar antigüedad del último backup
    LAST_BACKUP_TIME=$(find backups/databases -name "*.sql.gz" -type f -printf '%T@\n' 2>/dev/null | sort -nr | head -1)
    CURRENT_TIME=$(date +%s)
    
    if [ ! -z "$LAST_BACKUP_TIME" ]; then
        HOURS_SINCE=$(( ($CURRENT_TIME - ${LAST_BACKUP_TIME%.*}) / 3600 ))
        
        if [ "$HOURS_SINCE" -gt 24 ]; then
            print_warning "Último backup hace ${HOURS_SINCE} horas"
        else
            print_success "Backup reciente (${HOURS_SINCE} horas)"
        fi
    fi
else
    print_warning "No hay directorio de backups"
fi

################################################################################
# Logs Recientes
################################################################################

print_header "Alertas Recientes"

if [ -f "logs/alerts.log" ]; then
    RECENT_ALERTS=$(tail -5 logs/alerts.log 2>/dev/null)
    if [ ! -z "$RECENT_ALERTS" ]; then
        echo "$RECENT_ALERTS"
    else
        print_success "Sin alertas recientes"
    fi
else
    print_info "No hay archivo de alertas"
fi

################################################################################
# Resumen
################################################################################

print_header "Resumen"

# Contar servicios activos
ACTIVE_SERVICES=$(docker ps --format '{{.Names}}' | wc -l)
TOTAL_SERVICES=${#SERVICES[@]}

echo "Servicios activos: $ACTIVE_SERVICES/$TOTAL_SERVICES"

# Contar sitios respondiendo
RESPONDING_SITES=0
for i in {1..10}; do
    eval DOMAIN=\$DOMAIN_${i}
    [ -z "$DOMAIN" ] && continue
    
    HTTP_CODE=$(curl -o /dev/null -s -w "%{http_code}" -m 5 "http://${DOMAIN}" 2>/dev/null || echo "000")
    if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "301" ] || [ "$HTTP_CODE" = "302" ]; then
        ((RESPONDING_SITES++))
    fi
done

echo "Sitios respondiendo: $RESPONDING_SITES/10"

# Estado general
if [ "$ACTIVE_SERVICES" -eq "$TOTAL_SERVICES" ] && [ "$RESPONDING_SITES" -ge 8 ]; then
    print_success "Sistema operando normalmente"
elif [ "$ACTIVE_SERVICES" -ge 3 ] && [ "$RESPONDING_SITES" -ge 5 ]; then
    print_warning "Sistema operando con advertencias"
else
    print_error "Sistema requiere atención"
fi

echo ""
echo "Para ver logs detallados: tail -f $INSTALL_DIR/logs/monitor.log"
echo "Para ver alertas: tail -f $INSTALL_DIR/logs/alerts.log"

exit 0
