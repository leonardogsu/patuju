#!/bin/bash

################################################################################
# Script de Instalación Automática de WordPress
# Instala WordPress en todos los sitios configurados
################################################################################

set -e

INSTALL_DIR="/opt/wordpress-multisite"
cd "$INSTALL_DIR"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_success() { echo -e "${GREEN}✓${NC} $1"; }
print_error() { echo -e "${RED}✗${NC} $1"; }

# Cargar variables
source .env

print_header "Instalación Automática de WordPress"

# Descargar WordPress si no existe
if [ ! -f /tmp/wordpress-latest.tar.gz ]; then
    print_success "Descargando WordPress..."
    wget -q https://wordpress.org/latest.tar.gz -O /tmp/wordpress-latest.tar.gz
fi

# Instalar WordPress en cada sitio
for i in {1..10}; do
    SITE_DIR="www/sitio${i}"
    DB_NAME="wp_sitio${i}"
    eval DOMAIN=\$DOMAIN_${i}
    
    print_header "Instalando Sitio $i: $DOMAIN"
    
    # Crear directorio si no existe
    mkdir -p "$SITE_DIR"
    
    # Extraer WordPress
    if [ ! -f "$SITE_DIR/wp-config-sample.php" ]; then
        print_success "Extrayendo WordPress..."
        tar -xzf /tmp/wordpress-latest.tar.gz -C /tmp/
        cp -r /tmp/wordpress/* "$SITE_DIR/"
        rm -rf /tmp/wordpress
    else
        print_warning "WordPress ya existe, omitiendo extracción"
    fi
    
    # Generar claves de seguridad únicas
    print_success "Generando claves de seguridad..."
    SALT=$(curl -s https://api.wordpress.org/secret-key/1.1/salt/)
    
    # Crear wp-config.php
    if [ ! -f "$SITE_DIR/wp-config.php" ]; then
        print_success "Creando wp-config.php..."
        cat > "$SITE_DIR/wp-config.php" << EOF
<?php
/**
 * Configuración de WordPress - Sitio $i
 * Generado automáticamente el $(date)
 */

// ** Configuración de MySQL ** //
define('DB_NAME', '${DB_NAME}');
define('DB_USER', 'wpuser');
define('DB_PASSWORD', '${DB_PASSWORD}');
define('DB_HOST', 'mysql');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', 'utf8mb4_unicode_ci');

/**#@+
 * Claves únicas de autenticación y salado
 */
${SALT}
/**#@-*/

\$table_prefix = 'wp_';

/**
 * Modo de depuración
 */
define('WP_DEBUG', false);
define('WP_DEBUG_LOG', false);
define('WP_DEBUG_DISPLAY', false);

/**
 * Configuración de seguridad y rendimiento
 */
define('DISALLOW_FILE_EDIT', true);
define('DISALLOW_FILE_MODS', false);
define('WP_POST_REVISIONS', 5);
define('AUTOSAVE_INTERVAL', 300);
define('EMPTY_TRASH_DAYS', 30);
define('WP_MEMORY_LIMIT', '256M');
define('WP_MAX_MEMORY_LIMIT', '512M');

/**
 * Configuración de SSL
 */
if (isset(\$_SERVER['HTTP_X_FORWARDED_PROTO']) && \$_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    \$_SERVER['HTTPS'] = 'on';
}

/**
 * Configuración de caché
 */
define('WP_CACHE', true);

/** Ruta absoluta al directorio de WordPress */
if ( !defined('ABSPATH') )
    define('ABSPATH', dirname(__FILE__) . '/');

/** Configura las variables de WordPress y archivos incluidos */
require_once(ABSPATH . 'wp-settings.php');
EOF
    else
        print_warning "wp-config.php ya existe"
    fi
    
    # Configurar permisos
    print_success "Configurando permisos..."
    chown -R www-data:www-data "$SITE_DIR"
    find "$SITE_DIR" -type d -exec chmod 755 {} \;
    find "$SITE_DIR" -type f -exec chmod 644 {} \;
    chmod 600 "$SITE_DIR/wp-config.php"
    
    print_success "Sitio $i instalado: $DOMAIN"
    echo ""
done

# Limpiar
rm -f /tmp/wordpress-latest.tar.gz

print_header "Instalación Completada"

cat << EOF
${GREEN}✓ WordPress instalado en todos los sitios${NC}

Para completar la configuración:

1. Accede a cada dominio en tu navegador:
   $(for i in {1..10}; do eval echo "   - http://\$DOMAIN_${i}"; done)

2. Completa el asistente de instalación de WordPress

3. Considera instalar plugins recomendados:
   - WP Super Cache o W3 Total Cache (caché)
   - Wordfence Security (seguridad)
   - Akismet (anti-spam)
   - WP Optimize (optimización BD)

${YELLOW}⚠ IMPORTANTE:${NC}
- Usa contraseñas fuertes para cada instalación
- Configura backups automáticos
- Actualiza WordPress regularmente
EOF

