#!/bin/bash

################################################################################
# Script de Monitoreo Automatizado
# Verifica el estado de todos los servicios y envía alertas si es necesario
################################################################################

INSTALL_DIR="/opt/wordpress-multisite"
LOG_FILE="$INSTALL_DIR/logs/monitor.log"
ALERT_FILE="$INSTALL_DIR/logs/alerts.log"

cd "$INSTALL_DIR"

# Cargar variables
[ -f .env ] && source .env

# Umbrales de alerta
CPU_THRESHOLD=80
RAM_THRESHOLD=85
DISK_THRESHOLD=85
RESPONSE_TIME_THRESHOLD=3

log_alert() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] ALERTA: $1" | tee -a "$ALERT_FILE"
}

log_info() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] INFO: $1" >> "$LOG_FILE"
}

################################################################################
# Verificar Servicios Docker
################################################################################

check_services() {
    log_info "Verificando servicios Docker..."
    
    SERVICES=("nginx-web" "php-fpm" "mysql-db" "ftp-server")
    FAILED_SERVICES=()
    
    for service in "${SERVICES[@]}"; do
        if ! docker ps | grep -q "$service"; then
            FAILED_SERVICES+=("$service")
            log_alert "Servicio $service no está corriendo"
        fi
    done
    
    if [ ${#FAILED_SERVICES[@]} -gt 0 ]; then
        # Intentar reiniciar servicios
        log_info "Intentando reiniciar servicios..."
        docker compose restart "${FAILED_SERVICES[@]}" 2>/dev/null || true
        
        sleep 10
        
        # Verificar si se reiniciaron correctamente
        for service in "${FAILED_SERVICES[@]}"; do
            if ! docker ps | grep -q "$service"; then
                log_alert "CRÍTICO: No se pudo reiniciar $service"
            else
                log_info "Servicio $service reiniciado correctamente"
            fi
        done
    fi
}

################################################################################
# Verificar Uso de Recursos
################################################################################

check_resources() {
    log_info "Verificando recursos del sistema..."
    
    # CPU
    CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1 | cut -d'.' -f1)
    if [ "$CPU_USAGE" -ge "$CPU_THRESHOLD" ]; then
        log_alert "Uso de CPU alto: ${CPU_USAGE}%"
    fi
    
    # RAM
    RAM_USAGE=$(free | grep Mem | awk '{printf "%.0f", $3/$2 * 100.0}')
    if [ "$RAM_USAGE" -ge "$RAM_THRESHOLD" ]; then
        log_alert "Uso de RAM alto: ${RAM_USAGE}%"
    fi
    
    # Disco
    DISK_USAGE=$(df / | awk 'NR==2{print $5}' | cut -d'%' -f1)
    if [ "$DISK_USAGE" -ge "$DISK_THRESHOLD" ]; then
        log_alert "Uso de disco alto: ${DISK_USAGE}%"
    fi
    
    log_info "CPU: ${CPU_USAGE}% | RAM: ${RAM_USAGE}% | Disco: ${DISK_USAGE}%"
}

################################################################################
# Verificar Bases de Datos
################################################################################

check_databases() {
    log_info "Verificando bases de datos..."
    
    for i in {1..10}; do
        DB_NAME="wp_sitio${i}"
        
        if ! docker compose exec -T mysql mysql -u wpuser -p"${DB_PASSWORD}" -e "USE ${DB_NAME};" 2>/dev/null; then
            log_alert "Base de datos $DB_NAME no accesible"
        fi
    done
}

################################################################################
# Verificar Conectividad de Sitios
################################################################################

check_sites() {
    log_info "Verificando conectividad de sitios..."
    
    for i in {1..10}; do
        eval DOMAIN=\$DOMAIN_${i}
        
        # Verificar HTTP
        RESPONSE_TIME=$(curl -o /dev/null -s -w '%{time_total}\n' -m 5 "http://${DOMAIN}" 2>/dev/null || echo "999")
        RESPONSE_TIME_INT=$(echo "$RESPONSE_TIME" | cut -d'.' -f1)
        
        if [ "$RESPONSE_TIME_INT" -ge "$RESPONSE_TIME_THRESHOLD" ] || [ "$RESPONSE_TIME" = "999" ]; then
            log_alert "Sitio $DOMAIN responde lento o no responde (${RESPONSE_TIME}s)"
        fi
    done
}

################################################################################
# Verificar Espacio en Backups
################################################################################

check_backups() {
    log_info "Verificando espacio de backups..."
    
    if [ -d "$INSTALL_DIR/backups" ]; then
        BACKUP_SIZE=$(du -sh "$INSTALL_DIR/backups" | cut -f1)
        BACKUP_COUNT=$(find "$INSTALL_DIR/backups/databases" -name "*.sql.gz" 2>/dev/null | wc -l)
        
        log_info "Espacio de backups: $BACKUP_SIZE | Cantidad: $BACKUP_COUNT"
        
        # Verificar último backup
        LAST_BACKUP=$(find "$INSTALL_DIR/backups/databases" -name "*.sql.gz" -mtime -1 | wc -l)
        if [ "$LAST_BACKUP" -eq 0 ]; then
            log_alert "No se ha realizado backup en las últimas 24 horas"
        fi
    fi
}

################################################################################
# Verificar Logs de Errores
################################################################################

check_error_logs() {
    log_info "Verificando logs de errores..."
    
    # Buscar errores críticos en logs de Nginx
    if [ -d "$INSTALL_DIR/logs/nginx" ]; then
        CRITICAL_ERRORS=$(grep -i "crit\|emerg\|alert" "$INSTALL_DIR/logs/nginx"/*error.log 2>/dev/null | tail -5)
        
        if [ ! -z "$CRITICAL_ERRORS" ]; then
            log_alert "Errores críticos encontrados en Nginx"
        fi
    fi
    
    # Buscar errores en logs de PHP
    if [ -d "$INSTALL_DIR/logs/php" ]; then
        PHP_ERRORS=$(grep -i "fatal\|error" "$INSTALL_DIR/logs/php"/*.log 2>/dev/null | tail -5)
        
        if [ ! -z "$PHP_ERRORS" ]; then
            log_alert "Errores encontrados en PHP"
        fi
    fi
}

################################################################################
# Verificar Certificados SSL
################################################################################

check_ssl() {
    log_info "Verificando certificados SSL..."
    
    for i in {1..10}; do
        eval DOMAIN=\$DOMAIN_${i}
        
        if [ -f "$INSTALL_DIR/certbot/conf/live/${DOMAIN}/cert.pem" ]; then
            # Verificar fecha de expiración
            EXPIRY_DATE=$(openssl x509 -enddate -noout -in "$INSTALL_DIR/certbot/conf/live/${DOMAIN}/cert.pem" 2>/dev/null | cut -d= -f2)
            EXPIRY_EPOCH=$(date -d "$EXPIRY_DATE" +%s 2>/dev/null || echo "0")
            CURRENT_EPOCH=$(date +%s)
            DAYS_LEFT=$(( ($EXPIRY_EPOCH - $CURRENT_EPOCH) / 86400 ))
            
            if [ "$DAYS_LEFT" -lt 30 ]; then
                log_alert "Certificado SSL de $DOMAIN expira en $DAYS_LEFT días"
            fi
        fi
    done
}

################################################################################
# Limpiar Logs Antiguos
################################################################################

cleanup_logs() {
    # Mantener solo los últimos 100MB de logs
    LOG_SIZE=$(du -s "$INSTALL_DIR/logs" | awk '{print $1}')
    MAX_SIZE=$((100 * 1024)) # 100MB en KB
    
    if [ "$LOG_SIZE" -gt "$MAX_SIZE" ]; then
        log_info "Limpiando logs antiguos..."
        find "$INSTALL_DIR/logs" -name "*.log" -mtime +7 -delete
    fi
}

################################################################################
# Generar Reporte de Estado
################################################################################

generate_status_report() {
    cat > "$INSTALL_DIR/logs/status_report.txt" << EOF
========================================
Reporte de Estado del Sistema
Generado: $(date)
========================================

Servicios Docker:
$(docker compose ps)

Uso de Recursos:
- CPU: ${CPU_USAGE}%
- RAM: ${RAM_USAGE}%
- Disco: ${DISK_USAGE}%

Backups:
- Tamaño: $BACKUP_SIZE
- Cantidad: $BACKUP_COUNT

Alertas Recientes:
$(tail -10 "$ALERT_FILE" 2>/dev/null || echo "Sin alertas")

EOF
}

################################################################################
# Función Principal
################################################################################

main() {
    check_services
    check_resources
    check_databases
    check_sites
    check_backups
    check_error_logs
    check_ssl
    cleanup_logs
    generate_status_report
    
    log_info "Monitoreo completado"
}

# Ejecutar monitoreo
main

exit 0
