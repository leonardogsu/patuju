#!/bin/bash

################################################################################
# Script de Configuración SSL Automatizada
# Obtiene certificados Let's Encrypt para todos los dominios
################################################################################

set -e

INSTALL_DIR="/opt/wordpress-multisite"
cd "$INSTALL_DIR"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_success() { echo -e "${GREEN}✓${NC} $1"; }
print_error() { echo -e "${RED}✗${NC} $1"; }
print_warning() { echo -e "${YELLOW}⚠${NC} $1"; }

# Cargar variables
source .env

# Verificar email
if [ -z "$ADMIN_EMAIL" ]; then
    print_error "ADMIN_EMAIL no está configurado en .env"
    exit 1
fi

print_header "Configuración de Certificados SSL"

echo "Se obtendrán certificados para los siguientes dominios:"
for i in {1..10}; do
    eval DOMAIN=\$DOMAIN_${i}
    echo "  $i. $DOMAIN"
done

echo ""
read -p "¿Deseas continuar? (s/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Ss]$ ]]; then
    exit 0
fi

# Verificar que los dominios apuntan al servidor
print_header "Verificando DNS"

for i in {1..10}; do
    eval DOMAIN=\$DOMAIN_${i}
    
    print_success "Verificando $DOMAIN..."
    
    RESOLVED_IP=$(dig +short "$DOMAIN" | tail -1)
    
    if [ -z "$RESOLVED_IP" ]; then
        print_warning "No se pudo resolver $DOMAIN"
    elif [ "$RESOLVED_IP" != "$SERVER_IP" ]; then
        print_warning "$DOMAIN apunta a $RESOLVED_IP (se esperaba $SERVER_IP)"
    else
        print_success "$DOMAIN apunta correctamente a $SERVER_IP"
    fi
done

echo ""
read -p "¿Los dominios apuntan correctamente? Continuar de todos modos? (s/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Ss]$ ]]; then
    exit 0
fi

# Obtener certificados
print_header "Obteniendo Certificados SSL"

SUCCESS_COUNT=0
FAIL_COUNT=0

for i in {1..10}; do
    eval DOMAIN=\$DOMAIN_${i}
    
    print_success "Procesando $DOMAIN..."
    
    # Verificar si ya existe el certificado
    if [ -f "certbot/conf/live/${DOMAIN}/fullchain.pem" ]; then
        print_warning "Certificado ya existe para $DOMAIN (omitiendo)"
        ((SUCCESS_COUNT++))
        continue
    fi
    
    # Obtener certificado
    if docker compose run --rm certbot certonly \
        --webroot \
        --webroot-path=/var/www/certbot \
        --email "$ADMIN_EMAIL" \
        --agree-tos \
        --no-eff-email \
        --force-renewal \
        -d "$DOMAIN"; then
        
        print_success "Certificado obtenido para $DOMAIN"
        ((SUCCESS_COUNT++))
        
        # Actualizar configuración de Nginx para usar HTTPS
        update_nginx_config "$DOMAIN" "$i"
    else
        print_error "Error al obtener certificado para $DOMAIN"
        ((FAIL_COUNT++))
    fi
    
    # Esperar un poco entre solicitudes
    sleep 2
done

# Función para actualizar configuración de Nginx
update_nginx_config() {
    local domain=$1
    local site_num=$2
    
    cat > "nginx/conf.d/sitio${site_num}-ssl.conf" << EOF
# Configuración SSL para $domain

server {
    listen 80;
    server_name $domain;
    
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    
    location / {
        return 301 https://\$server_name\$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name $domain;
    
    root /var/www/html/sitio${site_num};
    index index.php index.html index.htm;
    
    # Certificados SSL
    ssl_certificate /etc/letsencrypt/live/${domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${domain}/privkey.pem;
    
    # Configuración SSL moderna
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # OCSP Stapling
    ssl_stapling on;
    ssl_stapling_verify on;
    ssl_trusted_certificate /etc/letsencrypt/live/${domain}/chain.pem;
    
    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Logs
    access_log /var/log/nginx/sitio${site_num}_access.log;
    error_log /var/log/nginx/sitio${site_num}_error.log;
    
    # Cliente
    client_max_body_size 100M;
    client_body_timeout 300s;
    
    # PHP
    location ~ \.php$ {
        fastcgi_pass php:9000;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_buffers 16 16k;
        fastcgi_buffer_size 32k;
        fastcgi_read_timeout 300;
    }
    
    # WordPress permalinks
    location / {
        try_files \$uri \$uri/ /index.php?\$args;
    }
    
    # Caché estática
    location ~* \.(jpg|jpeg|gif|png|css|js|ico|svg|woff|woff2|ttf|eot)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    # Denegar acceso a archivos sensibles
    location ~ /\. {
        deny all;
    }
    
    location ~ /wp-config.php {
        deny all;
    }
}
EOF
}

# Recargar Nginx
print_header "Aplicando Configuración"

print_success "Recargando Nginx..."
docker compose exec nginx nginx -s reload

print_header "Resumen"

echo "Certificados obtenidos: $SUCCESS_COUNT"
echo "Errores: $FAIL_COUNT"
echo ""

if [ $SUCCESS_COUNT -gt 0 ]; then
    print_success "Configuración SSL completada"
    echo ""
    echo "Sitios con HTTPS:"
    for i in {1..10}; do
        eval DOMAIN=\$DOMAIN_${i}
        if [ -f "certbot/conf/live/${DOMAIN}/fullchain.pem" ]; then
            echo "  ✓ https://$DOMAIN"
        fi
    done
else
    print_error "No se pudo obtener ningún certificado"
    echo ""
    echo "Verifica que:"
    echo "  1. Los dominios apuntan a la IP correcta"
    echo "  2. El puerto 80 está accesible públicamente"
    echo "  3. Los servicios Docker están corriendo"
fi

echo ""
print_success "Los certificados se renovarán automáticamente cada 12 horas"

exit 0
