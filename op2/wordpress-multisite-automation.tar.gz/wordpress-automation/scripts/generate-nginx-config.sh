#!/bin/bash

################################################################################
# Script de Generación de Configuración Nginx
# Genera configuraciones para todos los sitios
################################################################################

set -e

INSTALL_DIR="/opt/wordpress-multisite"
TEMPLATE_FILE="${INSTALL_DIR}/templates/nginx-site.conf.template"
OUTPUT_DIR="${INSTALL_DIR}/nginx/conf.d"

cd "$INSTALL_DIR"

# Cargar variables
source .env

echo "Generando configuraciones de Nginx..."

for i in {1..10}; do
    eval DOMAIN=\$DOMAIN_${i}
    
    if [ -z "$DOMAIN" ]; then
        echo "⚠ DOMAIN_${i} no configurado, omitiendo..."
        continue
    fi
    
    OUTPUT_FILE="${OUTPUT_DIR}/sitio${i}.conf"
    
    echo "  → Generando configuración para $DOMAIN (sitio${i})..."
    
    # Copiar template y reemplazar variables
    cat "$TEMPLATE_FILE" | \
        sed "s/{{SITE_NUM}}/${i}/g" | \
        sed "s/{{DOMAIN}}/${DOMAIN}/g" \
        > "$OUTPUT_FILE"
    
    echo "  ✓ Creado: $OUTPUT_FILE"
done

echo ""
echo "✓ Configuraciones generadas en $OUTPUT_DIR"
echo ""
echo "Para aplicar cambios:"
echo "  docker compose exec nginx nginx -t     # Verificar"
echo "  docker compose exec nginx nginx -s reload  # Aplicar"

exit 0
