#!/bin/bash

################################################################################
# Script de Optimización de Bases de Datos
# Optimiza y repara tablas WordPress automáticamente
################################################################################

set -e

INSTALL_DIR="/opt/wordpress-multisite"
cd "$INSTALL_DIR"

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1"
}

# Cargar variables
source .env

log "========================================="
log "Iniciando Optimización de Bases de Datos"
log "========================================="

# Optimizar cada base de datos
for i in {1..10}; do
    DB_NAME="wp_sitio${i}"
    
    log "Optimizando ${DB_NAME}..."
    
    # Analizar tablas
    log "  → Analizando tablas..."
    docker compose exec -T mysql mysqlcheck \
        -u wpuser \
        -p"${DB_PASSWORD}" \
        --analyze \
        --silent \
        "$DB_NAME" || true
    
    # Optimizar tablas
    log "  → Optimizando tablas..."
    docker compose exec -T mysql mysqlcheck \
        -u wpuser \
        -p"${DB_PASSWORD}" \
        --optimize \
        --silent \
        "$DB_NAME" || true
    
    # Reparar si es necesario
    log "  → Verificando integridad..."
    docker compose exec -T mysql mysqlcheck \
        -u wpuser \
        -p"${DB_PASSWORD}" \
        --auto-repair \
        --silent \
        "$DB_NAME" || true
    
    # Limpiar revisiones antiguas (mantener últimas 5)
    log "  → Limpiando revisiones antiguas..."
    docker compose exec -T mysql mysql \
        -u wpuser \
        -p"${DB_PASSWORD}" \
        "$DB_NAME" \
        -e "DELETE FROM wp_posts WHERE post_type = 'revision';" 2>/dev/null || true
    
    # Limpiar comentarios spam
    log "  → Limpiando spam..."
    docker compose exec -T mysql mysql \
        -u wpuser \
        -p"${DB_PASSWORD}" \
        "$DB_NAME" \
        -e "DELETE FROM wp_comments WHERE comment_approved = 'spam';" 2>/dev/null || true
    
    # Limpiar transients expirados
    log "  → Limpiando transients expirados..."
    docker compose exec -T mysql mysql \
        -u wpuser \
        -p"${DB_PASSWORD}" \
        "$DB_NAME" \
        -e "DELETE FROM wp_options WHERE option_name LIKE '_transient_%' OR option_name LIKE '_site_transient_%';" 2>/dev/null || true
    
    # Limpiar tablas huérfanas
    log "  → Limpiando metadata huérfana..."
    docker compose exec -T mysql mysql \
        -u wpuser \
        -p"${DB_PASSWORD}" \
        "$DB_NAME" \
        -e "DELETE pm FROM wp_postmeta pm LEFT JOIN wp_posts wp ON wp.ID = pm.post_id WHERE wp.ID IS NULL;" 2>/dev/null || true
    
    log "✓ ${DB_NAME} optimizado"
    echo ""
done

# Obtener estadísticas
log "========================================="
log "Estadísticas de Optimización"
log "========================================="

for i in {1..10}; do
    DB_NAME="wp_sitio${i}"
    
    SIZE=$(docker compose exec -T mysql mysql \
        -u wpuser \
        -p"${DB_PASSWORD}" \
        -e "SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS Size_MB FROM information_schema.TABLES WHERE table_schema = '${DB_NAME}';" \
        --skip-column-names --silent 2>/dev/null || echo "N/A")
    
    log "${DB_NAME}: ${SIZE} MB"
done

log "========================================="
log "Optimización Completada"
log "========================================="

exit 0
