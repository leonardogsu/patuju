#!/bin/bash

################################################################################
# Script de Instalación Automatizada - WordPress Multi-Sitio
# Para Ubuntu 24.04 LTS con 8GB RAM
# Versión: 2.0
################################################################################

set -e  # Salir si hay algún error

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # Sin color

# Directorio de instalación
INSTALL_DIR="/opt/wordpress-multisite"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

################################################################################
# Funciones auxiliares
################################################################################

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "Este script debe ejecutarse como root"
        echo "Usa: sudo bash $0"
        exit 1
    fi
}

check_system_requirements() {
    print_header "Verificando Requisitos del Sistema"
    
    # Verificar Ubuntu 24.04
    if ! grep -q "24.04" /etc/os-release; then
        print_warning "Este script está optimizado para Ubuntu 24.04"
        read -p "¿Deseas continuar de todos modos? (s/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Ss]$ ]]; then
            exit 1
        fi
    else
        print_success "Ubuntu 24.04 detectado"
    fi
    
    # Verificar memoria RAM (mínimo 7GB disponibles)
    ram_total=$(free -g | awk 'NR==2{print $2}')
    if [ "$ram_total" -lt 7 ]; then
        print_error "Se requieren al menos 8GB de RAM. Detectados: ${ram_total}GB"
        exit 1
    else
        print_success "RAM disponible: ${ram_total}GB"
    fi
    
    # Verificar espacio en disco (mínimo 30GB)
    disk_available=$(df / | awk 'NR==2{print $4}')
    disk_available_gb=$((disk_available / 1024 / 1024))
    if [ "$disk_available_gb" -lt 30 ]; then
        print_warning "Se recomienda al menos 30GB libres. Disponibles: ${disk_available_gb}GB"
    else
        print_success "Espacio en disco: ${disk_available_gb}GB"
    fi
}

install_dependencies() {
    print_header "Instalando Dependencias del Sistema"
    
    # Actualizar repositorios
    print_success "Actualizando repositorios..."
    apt-get update -qq
    
    # Instalar paquetes básicos
    print_success "Instalando paquetes esenciales..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        curl \
        wget \
        git \
        vim \
        htop \
        net-tools \
        unzip \
        software-properties-common \
        apt-transport-https \
        ca-certificates \
        gnupg \
        lsb-release \
        ufw \
        fail2ban \
        certbot \
        python3-certbot-nginx \
        logrotate \
        cron \
        rsync \
        jq \
        >/dev/null 2>&1
    
    print_success "Dependencias instaladas correctamente"
}

install_docker() {
    print_header "Instalando Docker y Docker Compose"
    
    if command -v docker &> /dev/null; then
        print_warning "Docker ya está instalado"
        docker --version
    else
        # Agregar repositorio oficial de Docker
        curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
        
        echo \
          "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
          $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
        
        apt-get update -qq
        apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin >/dev/null 2>&1
        
        # Iniciar Docker
        systemctl start docker
        systemctl enable docker
        
        print_success "Docker instalado: $(docker --version)"
    fi
    
    # Verificar Docker Compose
    if docker compose version &> /dev/null; then
        print_success "Docker Compose instalado: $(docker compose version)"
    else
        print_error "Error al instalar Docker Compose"
        exit 1
    fi
}

configure_firewall() {
    print_header "Configurando Firewall (UFW)"
    
    # Configurar UFW
    ufw --force reset >/dev/null 2>&1
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow 22/tcp comment 'SSH'
    ufw allow 80/tcp comment 'HTTP'
    ufw allow 443/tcp comment 'HTTPS'
    ufw allow 21/tcp comment 'FTP'
    ufw allow 21000:21010/tcp comment 'FTP Passive'
    echo "y" | ufw enable >/dev/null 2>&1
    
    print_success "Firewall configurado"
}

configure_fail2ban() {
    print_header "Configurando Fail2ban"
    
    cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = 22
logpath = /var/log/auth.log

[nginx-http-auth]
enabled = true
port = http,https
logpath = /opt/wordpress-multisite/logs/nginx/*error.log
EOF
    
    systemctl restart fail2ban
    systemctl enable fail2ban
    
    print_success "Fail2ban configurado"
}

create_directory_structure() {
    print_header "Creando Estructura de Directorios"
    
    mkdir -p "$INSTALL_DIR"/{nginx/{conf.d,cache},php,mysql/{data,init},www,logs/{nginx,php,mysql},backups,certbot/{conf,www},scripts,monitoring}
    
    # Crear directorios para cada sitio WordPress
    for i in {1..10}; do
        mkdir -p "$INSTALL_DIR/www/sitio${i}"
    done
    
    print_success "Estructura de directorios creada en $INSTALL_DIR"
}

generate_env_file() {
    print_header "Generando Archivo de Configuración (.env)"
    
    # Generar contraseñas seguras
    MYSQL_ROOT_PASSWORD=$(openssl rand -base64 24 | tr -d "=+/" | cut -c1-24)
    DB_PASSWORD=$(openssl rand -base64 24 | tr -d "=+/" | cut -c1-24)
    FTP_PASSWORD=$(openssl rand -base64 24 | tr -d "=+/" | cut -c1-24)
    
    # Obtener IP del servidor
    SERVER_IP=$(curl -s ifconfig.me || hostname -I | awk '{print $1}')
    
    cat > "$INSTALL_DIR/.env" << EOF
# Variables de entorno generadas automáticamente
# Fecha: $(date)

# MySQL
MYSQL_ROOT_PASSWORD=${MYSQL_ROOT_PASSWORD}
DB_PASSWORD=${DB_PASSWORD}

# FTP
FTP_PASSWORD=${FTP_PASSWORD}

# Servidor
SERVER_IP=${SERVER_IP}

# Dominios (EDITAR SEGÚN TUS NECESIDADES)
DOMAIN_1=guaman.es
DOMAIN_2=guaman.eu
DOMAIN_3=guaman.net
DOMAIN_4=guaman.org
DOMAIN_5=yeye.help
DOMAIN_6=yeyehelp.es
DOMAIN_7=yeyehelp.net
DOMAIN_8=yeyehelp.org
DOMAIN_9=yhlp.es
DOMAIN_10=leo.guaman.es

# Email para notificaciones
ADMIN_EMAIL=admin@${DOMAIN_1}

# Configuración de backups
BACKUP_RETENTION_DAYS=30
BACKUP_HOUR=2
EOF
    
    chmod 600 "$INSTALL_DIR/.env"
    
    print_success "Archivo .env generado con contraseñas seguras"
    print_warning "IMPORTANTE: Guarda estas contraseñas en un lugar seguro"
    echo ""
    echo "MySQL Root: ${MYSQL_ROOT_PASSWORD}"
    echo "DB User: ${DB_PASSWORD}"
    echo "FTP: ${FTP_PASSWORD}"
    echo ""
}

copy_configuration_files() {
    print_header "Copiando Archivos de Configuración"
    
    # Copiar configuraciones desde el proyecto
    if [ -d "$PROJECT_ROOT/config" ]; then
        cp -r "$PROJECT_ROOT/config"/* "$INSTALL_DIR/"
        print_success "Configuraciones copiadas desde $PROJECT_ROOT/config"
    fi
    
    # Copiar scripts
    if [ -d "$PROJECT_ROOT/scripts" ]; then
        cp -r "$PROJECT_ROOT/scripts"/* "$INSTALL_DIR/scripts/"
        chmod +x "$INSTALL_DIR/scripts"/*.sh
        print_success "Scripts copiados y permisos configurados"
    fi
    
    # Copiar templates
    if [ -d "$PROJECT_ROOT/templates" ]; then
        cp -r "$PROJECT_ROOT/templates" "$INSTALL_DIR/"
        print_success "Templates copiados"
    fi
}

setup_system_optimization() {
    print_header "Optimizando Sistema para WordPress"
    
    # Configurar límites del sistema
    cat >> /etc/security/limits.conf << 'EOF'
* soft nofile 65536
* hard nofile 65536
* soft nproc 32768
* hard nproc 32768
EOF
    
    # Optimizar kernel para mejor rendimiento
    cat >> /etc/sysctl.conf << 'EOF'

# Optimizaciones para WordPress Multi-Sitio
net.core.somaxconn = 65535
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 15
vm.swappiness = 10
vm.overcommit_memory = 1
EOF
    
    sysctl -p >/dev/null 2>&1
    
    print_success "Optimizaciones del sistema aplicadas"
}

setup_log_rotation() {
    print_header "Configurando Rotación de Logs"
    
    cat > /etc/logrotate.d/wordpress-multisite << 'EOF'
/opt/wordpress-multisite/logs/*/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
    postrotate
        docker exec nginx-web nginx -s reload > /dev/null 2>&1 || true
    endscript
}
EOF
    
    print_success "Rotación de logs configurada"
}

setup_cron_jobs() {
    print_header "Configurando Tareas Programadas"
    
    # Crear crontab para root
    (crontab -l 2>/dev/null || echo "") | grep -v "wordpress-multisite" > /tmp/crontab.tmp
    
    cat >> /tmp/crontab.tmp << EOF
# WordPress Multi-Sitio - Tareas automatizadas

# Backups diarios a las 2 AM
0 2 * * * ${INSTALL_DIR}/scripts/backup.sh >> ${INSTALL_DIR}/logs/backup.log 2>&1

# Actualizaciones de seguridad semanales (domingos a las 3 AM)
0 3 * * 0 ${INSTALL_DIR}/scripts/update.sh >> ${INSTALL_DIR}/logs/update.log 2>&1

# Monitoreo cada 5 minutos
*/5 * * * * ${INSTALL_DIR}/scripts/monitor.sh >> ${INSTALL_DIR}/logs/monitor.log 2>&1

# Limpieza de logs antiguos (mensual)
0 4 1 * * find ${INSTALL_DIR}/logs -type f -name "*.log" -mtime +30 -delete

# Optimización de bases de datos (semanal)
0 5 * * 0 ${INSTALL_DIR}/scripts/optimize-db.sh >> ${INSTALL_DIR}/logs/optimize.log 2>&1

# Renovación de certificados SSL
0 0 * * * docker compose -f ${INSTALL_DIR}/docker-compose.yml exec -T certbot certbot renew --quiet
EOF
    
    crontab /tmp/crontab.tmp
    rm /tmp/crontab.tmp
    
    print_success "Tareas programadas configuradas"
}

create_systemd_service() {
    print_header "Creando Servicio Systemd"
    
    cat > /etc/systemd/system/wordpress-multisite.service << EOF
[Unit]
Description=WordPress Multi-Sitio Docker
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/docker compose up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=300

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable wordpress-multisite.service
    
    print_success "Servicio systemd creado"
}

print_next_steps() {
    print_header "Instalación Completada"
    
    cat << EOF
${GREEN}✓ Instalación base completada exitosamente${NC}

Próximos pasos:

1. Editar dominios en: ${INSTALL_DIR}/.env

2. Iniciar los servicios:
   ${BLUE}cd ${INSTALL_DIR}${NC}
   ${BLUE}sudo bash scripts/deploy.sh${NC}

3. Configurar certificados SSL:
   ${BLUE}sudo bash scripts/setup-ssl.sh${NC}

4. Instalar WordPress en cada sitio:
   ${BLUE}sudo bash scripts/install-wordpress.sh${NC}

5. Ver el estado del sistema:
   ${BLUE}sudo bash scripts/status.sh${NC}

Ubicación del proyecto: ${INSTALL_DIR}

Contraseñas generadas guardadas en: ${INSTALL_DIR}/.env

${YELLOW}⚠ IMPORTANTE: Haz un backup del archivo .env en un lugar seguro${NC}

Para más información, consulta: ${INSTALL_DIR}/docs/MANUAL.md
EOF
}

################################################################################
# Función principal
################################################################################

main() {
    print_header "WordPress Multi-Sitio - Instalación Automatizada"
    
    check_root
    check_system_requirements
    install_dependencies
    install_docker
    configure_firewall
    configure_fail2ban
    create_directory_structure
    generate_env_file
    copy_configuration_files
    setup_system_optimization
    setup_log_rotation
    setup_cron_jobs
    create_systemd_service
    print_next_steps
}

# Ejecutar instalación
main

exit 0
